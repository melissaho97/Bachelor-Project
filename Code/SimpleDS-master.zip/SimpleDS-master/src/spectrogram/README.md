# spectrogram
A toy spectrogram tool in Python -- from Travis Mick. 

Adapted by H. Cuayahuitl for its application to dialogue systems.
